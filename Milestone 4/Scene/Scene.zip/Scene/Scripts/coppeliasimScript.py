import sympy as sp
import numpy as np
import math
def sysCall_init():
    sim = require('sim')

    self.joints = [
        sim.getObject("../2"),
        sim.getObject("../3"),
        sim.getObject("../4"),
        sim.getObject("../5")
        ]

        # Simulation start time
    self.start_time = sim.getSimulationTime()


    self.link_lengths = compute_link_lengths()
    
    # Joint Space trajectory
    self.trajectory_duration = 5
    self.task_duration = 3 
    
    x0_joint = np.array(sim.getObjectPosition(sim.getObject("/EndEffector"),sim.getObject("../BaseFrame")))
    xf_joint = np.array([0, 0.9, 0.3])
    self.equations = calculate_joint_space_trajectory_equations(x0_joint,xf_joint,self.trajectory_duration)


    x2_trajectory = np.array([0, 0.9, 0.3])
    x2f_trajectory = np.array([0, 0.9, 0])
    self.angles = task_space_trajectory(0.1, x2_trajectory, x2f_trajectory, self.task_duration)

    self.start_time =sim.getSimulationTime()


def sysCall_actuation():
    # Joint Space trajectory
    
    curr_time = sim.getSimulationTime() - self.start_time
    
    
    if curr_time <= self.trajectory_duration:
        normalized_time = curr_time
        joint_positions = [self.equations[joint_id].subs(sp.symbols('t'), normalized_time).evalf() 
            for joint_id in range(1, 5)]

        print(sim.getObjectPosition(sim.getObject("/EndEffector"),sim.getObject("../BaseFrame")))
        for obj, position in zip(self.joints, joint_positions):
            position = float(position) 
            sim.setJointTargetPosition(obj, position)
    else:
        prev_point, next_point = None, None
        for i in range(len(self.angles) - 1):
            if self.angles[i]["time"] <= curr_time-self.trajectory_duration and self.angles[i + 1]["time"] >= curr_time-self.trajectory_duration:
                prev_point = self.angles[i]
                next_point = self.angles[i + 1]
                break

        if prev_point and next_point:
                # Interpolate joint angles
            alpha = (curr_time-self.trajectory_duration - prev_point["time"]) / (next_point["time"] - prev_point["time"])
            for i, joint in enumerate(self.joints):
                angle = prev_point["angles"][i] * (1 - alpha) + next_point["angles"][i] * alpha
                sim.setJointTargetPosition(joint, angle)
        elif next_point is None:
                # If beyond the last point, set to final angles
            final_point = self.angles[-1]
            for i, joint in enumerate(self.joints):
                sim.setJointTargetPosition(joint, final_point["angles"][i])

    
    
    
def sysCall_cleanup():
    EEPosition = sim.getObjectPosition(sim.getObject("/EndEffector"),sim.getObject("../2"))
    print(sim.getObjectPosition(sim.getObject("/EndEffector"),sim.getObject("../BaseFrame")))
    print(sim.getObjectPosition(sim.getObject("/EndEffector"),sim.getObject("../BaseFrame")))
    '''
    theta = sp.symbols('q1 q2 q3 q4')  
    
    T1 = transformation_func(theta[0] , 0.853*sp.symbols('L1'), 0.522*sp.symbols('L1'), sp.pi/2)
    
    T2 = transformation_func(theta[1], 0, sp.symbols('L2'), 0)
    
    T3 = transformation_func(theta[2], 0, sp.symbols('L3'), 0)
    
    T4 = transformation_func(theta[3], 0, sp.symbols('L4'), 0)
    matrix = []
    
    matrix.append(T1)
    matrix.append(T2)
    matrix.append(T3)
    matrix.append(T4)
    final_matrix = matrix[0] * matrix[1] * matrix[2] * matrix[3]
    
    print("Final Matrix:")
    for i in range(final_matrix.rows):
        print(f"Row {i+1}: {final_matrix.row(i)}")
    
    for i, m in enumerate(matrix):
        print(f"T{i+1}:\n{m}\n")
 
    '''
    
    '''
    L1, L2, L3, L4 = [self.link_lengths[0],self.link_lengths[1], self.link_lengths[2], self.link_lengths[3]]
    T1 = transformation_func(self.target_angles[0], 0.853*L1, 0.522*L1, sp.pi/2)
    
    T2 = transformation_func(self.target_angles[1], 0, L2, 0)
    
    T3 = transformation_func(self.target_angles[2], 0, L3, 0)
    
    T4 = transformation_func(self.target_angles[3], 0, L4, 0)
    matrix = []
    
    matrix.append(T1)
    matrix.append(T2)
    matrix.append(T3)
    matrix.append(T4)
    final_matrix = matrix[0] * matrix[1] * matrix[2] * matrix[3]
    
    print("Final Matrix:")
    for i in range(final_matrix.rows):
        print(f"Row {i+1}: {final_matrix.row(i)}")
    
    for i, m in enumerate(matrix):
        print(f"T{i+1}:\n{m}\n")
    '''
  
    '''
    batee5 = sp.symbols('X Y Z')
    q1, q3 = inverse_position_kinematics(-0.0770658314629956, -0.0646194449152991, 0.284051314247094, 0.35, 0.364, 0.126305)
    print(q1)
    print(q3)
    '''

    pass

def transformation_func(theta, d, a, alpha):

    
    T = sp.Matrix([[sp.cos(theta), -sp.sin(theta)*sp.cos(alpha), sp.sin(theta)*sp.sin(alpha), a*sp.cos(theta)],
                   [sp.sin(theta),  sp.cos(theta)*sp.cos(alpha), -sp.cos(theta)*sp.sin(alpha), a*sp.sin(theta)],
                   [0,              sp.sin(alpha),               sp.cos(alpha),               d],
                   [0,              0,                           0,                           1]])

    return T

def inverse_position_kinematics(mu_a):
    q1, q2, q3, q4, L1, L2, L3, L4 = sp.symbols('q1 q2 q3 q4 L1 L2 L3 L4', real=True)
    X = 0.522*L1*sp.cos(q1) + L2*sp.cos(q1)*sp.cos(q2) - L3*sp.sin(q2)*sp.sin(q3)*sp.cos(q1) \
        + L3*sp.cos(q1)*sp.cos(q2)*sp.cos(q3) + L4*(-sp.sin(q2)*sp.sin(q3)*sp.cos(q1) + sp.cos(q1)*sp.cos(q2)*sp.cos(q3))*sp.cos(q4) \
        + L4*(-sp.sin(q2)*sp.cos(q1)*sp.cos(q3) -
            sp.sin(q3)*sp.cos(q1)*sp.cos(q2))*sp.sin(q4)

    Y = 0.522*L1*sp.sin(q1) + L2*sp.sin(q1)*sp.cos(q2) - L3*sp.sin(q1)*sp.sin(q2)*sp.sin(q3) \
        + L3*sp.sin(q1)*sp.cos(q2)*sp.cos(q3) + L4*(-sp.sin(q1)*sp.sin(q2)*sp.sin(q3) + sp.sin(q1)*sp.cos(q2)*sp.cos(q3))*sp.cos(q4) \
        + L4*(-sp.sin(q1)*sp.sin(q2)*sp.cos(q3) -
            sp.sin(q1)*sp.sin(q3)*sp.cos(q2))*sp.sin(q4)

    Z = 0.853*L1 + L2*sp.sin(q2) + L3*sp.sin(q2)*sp.cos(q3) \
        + L3*sp.sin(q3)*sp.cos(q2) + L4*(-sp.sin(q2)*sp.sin(q3) + sp.cos(q2)*sp.cos(q3))*sp.sin(q4) \
        + L4*(sp.sin(q2)*sp.cos(q3) + sp.sin(q3)*sp.cos(q2))*sp.cos(q4)

    mu_e = sp.Matrix([X, Y, Z])
    J = mu_e.jacobian([q1, q2, q3, q4])

    L1_val, L2_val, L3_val, L4_val = 0.2872716484444307, 0.349999999999999, 0.3637938976948305, 0.12629975955638376

    # mu_a = np.array([0.6, 0.3, 0.4])

    max_reach = L1_val + L2_val + L3_val + L4_val
    if np.linalg.norm(mu_a) > max_reach:
        raise ValueError("Target is outside the robot's workspace.")

    q = np.array([0, 0, 0, 0], dtype=float)

    delta = np.array([10**10, 10**10, 10**10])

    max_iterations = 1000
    iteration = 0

    while np.linalg.norm(delta) > 0.00001:
        iteration += 1
        q_vals = {q1: q[0], q2: q[1], q3: q[2], q4: q[3],
                L1: L1_val, L2: L2_val, L3: L3_val, L4: L4_val}

        mu_e_val = np.array(mu_e.subs(q_vals).evalf(), dtype=float).flatten()
        J_val = np.array(J.subs(q_vals).evalf(), dtype=float)

        delta = mu_a - mu_e_val

        q += np.dot(np.linalg.pinv(J_val), delta)
        if iteration >= max_iterations:
            print("Max iterations reached, restarting with random joint angles.")
            q = np.random.uniform(0, 2 * np.pi, size=4)  # New random joint angles
            iteration = 0  # Reset iteration count

    print(f'Final solution: q1 = {q[0]}, q2 = {q[1]}, q3 = {q[2]}, q4 = {q[3]}')
    q_normalized = np.mod(q + np.pi, 2 * np.pi) - np.pi
    print(f'Normalized solution: q1 = {q_normalized[0]}, q2 = {q_normalized[1]}, q3 = {q_normalized[2]}, q4 = {q_normalized[3]}')
    return q_normalized
    
def calculate_joint_space_trajectory_equations(x0,xf,T):

    t = sp.symbols('t')
    q0 = inverse_position_kinematics(x0)
    qf = inverse_position_kinematics(xf)
    equations = {}

    for i, (q0_i, qf_i) in enumerate(zip(q0, qf)):
        coeffs = calculate_5th_order_coefficients(q0_i, qf_i, T)
        q_t = sum(coeffs[j] * t**j for j in range(6))
        equations[i+1] = q_t

    for joint, equation in equations.items():
        print(f"{joint} = {equation}")
    return equations
    
def calculate_5th_order_coefficients(q0, qf, T):
    A = np.array([
        [T**3, T**4, T**5],
        [3*T**2, 4*T**3, 5*T**4],
        [6*T, 12*T**2, 20*T**3]
    ])

    b = np.array([
        qf - q0,
        0,  # Final velocity = 0
        0   # Final acceleration = 0
    ])
    # Solve for a3, a4, a5
    a3, a4, a5 = np.linalg.solve(A, b)
    return [q0, 0, 0, a3, a4, a5]
    
def trajectoryEquations(t, initial_position, final_position, total_time):
    initial_position = np.array(initial_position)
    final_position = np.array(final_position)
    # Compute the position at time t
    slopes = (final_position - initial_position) / total_time

    # Compute the position at time t
    position = initial_position + slopes * t
    return position
    
def task_space_trajectory( time_sample, initial_position, final_position, total_time):
    time_points = np.arange(0, total_time + time_sample, time_sample)
    joint_angles = np.array([0, 0, 0, 0], dtype=float)
    angles = []

    for t in time_points:
        mu_a = trajectoryEquations(t, initial_position, final_position, total_time)
        joint_angles = inverse_position_kinematics_trajectory(mu_a, joint_angles)
        angles_dictionary = {}
        angles_dictionary["time"] = float(t)
        angles_dictionary["angles"] = joint_angles
        angles.append(angles_dictionary)
    return angles

def inverse_position_kinematics_trajectory(mu_a, q_initial):
    q1, q2, q3, q4, L1, L2, L3, L4 = sp.symbols('q1 q2 q3 q4 L1 L2 L3 L4', real=True)
    X = 0.522*L1*sp.cos(q1) + L2*sp.cos(q1)*sp.cos(q2) - L3*sp.sin(q2)*sp.sin(q3)*sp.cos(q1) \
        + L3*sp.cos(q1)*sp.cos(q2)*sp.cos(q3) + L4*(-sp.sin(q2)*sp.sin(q3)*sp.cos(q1) + sp.cos(q1)*sp.cos(q2)*sp.cos(q3))*sp.cos(q4) \
        + L4*(-sp.sin(q2)*sp.cos(q1)*sp.cos(q3) -
            sp.sin(q3)*sp.cos(q1)*sp.cos(q2))*sp.sin(q4)

    Y = 0.522*L1*sp.sin(q1) + L2*sp.sin(q1)*sp.cos(q2) - L3*sp.sin(q1)*sp.sin(q2)*sp.sin(q3) \
        + L3*sp.sin(q1)*sp.cos(q2)*sp.cos(q3) + L4*(-sp.sin(q1)*sp.sin(q2)*sp.sin(q3) + sp.sin(q1)*sp.cos(q2)*sp.cos(q3))*sp.cos(q4) \
        + L4*(-sp.sin(q1)*sp.sin(q2)*sp.cos(q3) -
            sp.sin(q1)*sp.sin(q3)*sp.cos(q2))*sp.sin(q4)

    Z = 0.853*L1 + L2*sp.sin(q2) + L3*sp.sin(q2)*sp.cos(q3) \
        + L3*sp.sin(q3)*sp.cos(q2) + L4*(-sp.sin(q2)*sp.sin(q3) + sp.cos(q2)*sp.cos(q3))*sp.sin(q4) \
        + L4*(sp.sin(q2)*sp.cos(q3) + sp.sin(q3)*sp.cos(q2))*sp.cos(q4)

    mu_e = sp.Matrix([X, Y, Z])
    J = mu_e.jacobian([q1, q2, q3, q4])

    L1_val, L2_val, L3_val, L4_val = 0.2872716484444307, 0.349999999999999, 0.3637938976948305, 0.12629975955638376

    # mu_a = np.array([0.6, 0.3, 0.4])

    max_reach = L1_val + L2_val + L3_val + L4_val
    if np.linalg.norm(mu_a) > max_reach:
        raise ValueError("Target is outside the robot's workspace.")

    q = q_initial

    delta = np.array([10**10, 10**10, 10**10])

    max_iterations = 1000
    iteration = 0

    while np.linalg.norm(delta) > 0.00001:
        iteration += 1
        q_vals = {q1: q[0], q2: q[1], q3: q[2], q4: q[3],
                L1: L1_val, L2: L2_val, L3: L3_val, L4: L4_val}

        mu_e_val = np.array(mu_e.subs(q_vals).evalf(), dtype=float).flatten()
        J_val = np.array(J.subs(q_vals).evalf(), dtype=float)

        delta = mu_a - mu_e_val

        q += np.dot(np.linalg.pinv(J_val), delta)
        if iteration >= max_iterations:
            print("Max iterations reached, restarting with random joint angles.")
            q = np.random.uniform(0, 2 * np.pi, size=4)  # New random joint angles
            iteration = 0  # Reset iteration count

    q_normalized = np.mod(q + np.pi, 2 * np.pi) - np.pi
    return q_normalized    

def compute_link_lengths():
    sim = require('sim')

    joint_handles = [
        sim.getObject("../BaseFrame"),  # First joint
        sim.getObject("../3"),  # Second joint
        sim.getObject("../4"),  # Third joint
        sim.getObject("../5"),  # Fourth joint
        sim.getObject("/EndEffector")
    ]
    

    joint_positions = [sim.getObjectPosition(handle, -1) for handle in joint_handles]

    link_lengths = []
    for i in range(len(joint_positions) - 1):

        start = joint_positions[i]
        end = joint_positions[i + 1]
        length = ((end[0] - start[0])**2 + (end[1] - start[1])**2 + (end[2] - start[2])**2)**0.5
        link_lengths.append(length)

    for i, length in enumerate(link_lengths):
        print(f"Length of link {i + 1}: {length}")
    return link_lengths

# See the user manual or the available code snippets for additional callback functions and details